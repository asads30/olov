module.exports = {
   TOKEN: "1949226969:AAEEuRAlb2iqY8KofTHynBCB7glrziCwd5Y",
};
