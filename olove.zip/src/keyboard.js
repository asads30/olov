const kb = require("./keyboard-buttons");

module.exports = {
   phone: [[kb.phone.number]],
};
