module.exports = {
   phone: {
      number: "📞 Отправить контакт",
   },
   back: "Назад",
};
