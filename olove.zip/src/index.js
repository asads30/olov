process.env.NTBA_FIX_319 = 1;
const TelegramBot = require("node-telegram-bot-api");
const keyboard = require("./keyboard");
const kb = require("./keyboard-buttons");
const config = require("./config");
const helpers = require("./helpers");
const mysql = require("mysql");
const bot = new TelegramBot(config.TOKEN, {
   polling: true,
});

/* DB */
var db_config = {
   host: "localhost",
   user: "root",
   password: "",
   database: "olov",
};
var connection;

function handleDisconnect() {
   connection = mysql.createConnection(db_config);
   connection.connect(function (err) {
      if (err) {
         console.log("error when connecting to db:", err);
         setTimeout(handleDisconnect, 2000);
      }
   });
   connection.on("error", function (err) {
      console.log("db error", err);
      if (err.code === "PROTOCOL_CONNECTION_LOST") {
         handleDisconnect();
      } else {
         throw err;
      }
   });
}

handleDisconnect();

/* Global */

const admin = 386567097;

bot.onText(/\/start/, (msg) => {
   let regName = msg.from.first_name;
   let regUsername = msg.from.username;
   const text = `Здравствуйте, ${msg.from.first_name}\n\n👥 Выбор языка/Tilni tanlash:`;
   connection.query(
      "SELECT * FROM users WHERE userid = ?",
      [helpers.getUserId(msg)],
      (error, results) => {
         if (error) {
            console.log("Ошибка при поиске в users", error);
         } else {
            if (results.length === 0) {
               const user = [regName, helpers.getUserId(msg), regUsername, 1];
               const sql =
                  "INSERT INTO users(name, userid, username, step) VALUES(?, ?, ?, ?)";
               connection.query(sql, user, function (err, results) {
                  if (err) console.log(err);
                  else console.log("Юзер зареган");
               });
               bot.sendMessage(helpers.getChatId(msg), text, {
                  reply_markup: {
                     resize_keyboard: true,
                     inline_keyboard: [
                        [
                           {
                              text: "🇷🇺 Русский",
                              callback_data: "ru",
                           },
                           {
                              text: "🇺🇿 O'zbek tili",
                              callback_data: "uz",
                           },
                        ],
                     ],
                  },
               });
            } else {
            }
         }
      }
   );
});

bot.on("message", (msg) => {
   let userId = msg.from.id;
   connection.query(
      "SELECT * FROM users WHERE userid = ?",
      [helpers.getUserId(msg)],
      (error, results) => {
         if (error) {
            console.log("Ошибка при поиске в users", error);
         } else {
            if (results.length === 0) {
            } else if (results[0].step == 2) {
               userPhone = msg.text;
               const sql =
                  "UPDATE users SET step = ? , phone = ? WHERE userid = ?";
               connection.query(
                  sql,
                  [3, userPhone, userId],
                  function (err, results) {
                     if (err) console.log(err);
                     else {
                     }
                  }
               );
               bot.sendMessage(userId, "Откуда Вы узнали про приложение", {
                  reply_markup: {
                     resize_keyboard: true,
                     inline_keyboard: [
                        [
                           {
                              text: "Страница OLOVE в Инстаграм",
                              callback_data: "var1-1",
                           },
                        ],
                        [
                           {
                              text: "Страница других пользователей в Инстаграм",
                              callback_data: "var1-2",
                           },
                        ],
                        [
                           {
                              text: "Знакомых",
                              callback_data: "var1-3",
                           },
                        ],
                        [
                           {
                              text: "Другое",
                              callback_data: "var1-4",
                           },
                        ],
                     ],
                  },
               });
            }
         }
      }
   );
});

bot.on("callback_query", (callbackQuery) => {
   const msg = callbackQuery.message;
   const userId = callbackQuery.from.id;
   const msgId = callbackQuery.data;
   if (msgId === "ru") {
      bot.answerCallbackQuery(callbackQuery.id).then(() =>
         bot.sendMessage(
            msg.chat.id,
            "Чтобы зарегистрироваться отправьте свой номер телефона. Например, +998xx xxx xx xx"
         )
      );
      bot.deleteMessage(msg.chat.id, msg.message_id);
      connection.query(
         "SELECT * FROM users WHERE userid = ?",
         [userId],
         (error, results) => {
            if (error) {
               console.log(error, "1");
            } else {
               if (results.length === 0) {
                  console.log("2");
               } else {
                  const sql = "UPDATE users SET step = '2' WHERE userid = ?";
                  connection.query(sql, userId, function (err, results) {
                     if (err) console.log(err, "3");
                     else console.log("4");
                  });
               }
            }
         }
      );
   } else if (msgId === "var1-1") {
      bot.answerCallbackQuery(callbackQuery.id).then(() =>
         bot.sendMessage(
            msg.chat.id,
            "Насколько удобно было пройти регистрацию в приложении? от 1 до 5. Где 1-нудобно, 5-очень удобно.",
            {
               reply_markup: {
                  resize_keyboard: true,
                  inline_keyboard: [
                     [
                        {
                           text: "1️⃣",
                           callback_data: "var2-1",
                        },
                     ],
                     [
                        {
                           text: "2️⃣",
                           callback_data: "var2-2",
                        },
                     ],
                     [
                        {
                           text: "3️⃣",
                           callback_data: "var2-3",
                        },
                     ],
                     [
                        {
                           text: "4️⃣",
                           callback_data: "var2-4",
                        },
                     ],
                     [
                        {
                           text: "5️⃣",
                           callback_data: "var2-5",
                        },
                     ],
                  ],
               },
            }
         )
      );
      bot.deleteMessage(msg.chat.id, msg.message_id);
   } else if (msgId === "var2-1") {
      bot.answerCallbackQuery(callbackQuery.id).then(() =>
         bot.sendMessage(msg.chat.id, "Будете ли Вы использовать приложение?", {
            reply_markup: {
               resize_keyboard: true,
               inline_keyboard: [
                  [
                     {
                        text: "Да",
                        callback_data: "var3-1",
                     },
                     {
                        text: "Нет",
                        callback_data: "var3-2",
                     },
                  ],
               ],
            },
         })
      );
      bot.deleteMessage(msg.chat.id, msg.message_id);
   } else if (msgId === "var3-1") {
      bot.answerCallbackQuery(callbackQuery.id).then(() =>
         bot.sendMessage(
            msg.chat.id,
            "Спасибо за уделенное время. Мы только запустили наше приложение, и Ваше мнение очень ценно для нас. 1 сентября мы объявим победителей нашего конкурса и вручим ценные призы. Оставайтесь с нами, впереди вас ждет много интересного."
         )
      );
      bot.deleteMessage(msg.chat.id, msg.message_id);
   }
});
